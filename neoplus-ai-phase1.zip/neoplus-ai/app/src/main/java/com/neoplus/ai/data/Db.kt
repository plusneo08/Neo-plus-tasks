package com.neoplus.ai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity_log")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val source: String,
    val message: String,
    val status: String // OK, FAILED, BLOCKED
)

/** Text is stored encrypted with the Android Keystore key. */
@Entity(tableName = "memory_item")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val encryptedText: String,
    val createdAt: Long
)

@Entity(tableName = "app_connection")
data class AppConnection(
    @PrimaryKey val packageName: String,
    val label: String,
    val connected: Boolean,
    val monitoring: Boolean,
    val updatedAt: Long
)

@Dao
interface LogDao {
    @Insert suspend fun insert(log: ActivityLog)
    @Query("SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT 200")
    fun recent(): Flow<List<ActivityLog>>
    @Query("DELETE FROM activity_log") suspend fun clear()
}

@Dao
interface MemoryDao {
    @Insert suspend fun insert(item: MemoryItem)
    @Query("SELECT * FROM memory_item ORDER BY createdAt DESC")
    fun all(): Flow<List<MemoryItem>>
    @Query("SELECT COUNT(*) FROM memory_item WHERE id = :id") suspend fun exists(id: Long): Int
    @Query("DELETE FROM memory_item WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memory_item") suspend fun clear()
}

@Dao
interface ConnectionDao {
    @Upsert suspend fun upsert(c: AppConnection)
    @Query("SELECT * FROM app_connection WHERE packageName = :pkg")
    suspend fun get(pkg: String): AppConnection?
    @Query("SELECT * FROM app_connection")
    fun all(): Flow<List<AppConnection>>
    @Query("DELETE FROM app_connection") suspend fun clear()
}

@Database(
    entities = [ActivityLog::class, MemoryItem::class, AppConnection::class],
    version = 1,
    exportSchema = false
)
abstract class NeoDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao
    abstract fun memoryDao(): MemoryDao
    abstract fun connectionDao(): ConnectionDao

    companion object {
        @Volatile private var inst: NeoDatabase? = null
        fun get(ctx: Context): NeoDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, NeoDatabase::class.java, "neoplus.db")
                .build().also { inst = it }
        }
    }
}
