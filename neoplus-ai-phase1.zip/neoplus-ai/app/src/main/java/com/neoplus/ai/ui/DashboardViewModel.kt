package com.neoplus.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.neoplus.ai.data.*
import com.neoplus.ai.integration.AppEntry
import com.neoplus.ai.integration.IntegrationManager
import com.neoplus.ai.security.KeystoreVault
import com.neoplus.ai.security.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class Memory(val id: Long, val text: String, val createdAt: Long)

class DashboardViewModel(app: Application) : AndroidViewModel(app) {
    private val db = NeoDatabase.get(app)
    private val prefs = Prefs(app)
    private val integrations = IntegrationManager(app)

    val stopped = MutableStateFlow(prefs.emergencyStop)
    val accent = MutableStateFlow(prefs.accent)
    val hasApiKey = MutableStateFlow(prefs.hasApiKey())
    val apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val message = MutableStateFlow<String?>(null)

    private fun <T> Flow<T>.hot(init: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    val logs = db.logDao().recent().hot(emptyList())
    val connections = db.connectionDao().all().hot(emptyList())
    val memories = db.memoryDao().all()
        .map { list ->
            list.map {
                Memory(it.id, runCatching { KeystoreVault.decrypt(it.encryptedText) }
                    .getOrDefault("(unreadable)"), it.createdAt)
            }
        }.flowOn(Dispatchers.Default).hot(emptyList())

    init { refreshApps() }

    private suspend fun log(source: String, msg: String, status: String = "OK") =
        db.logDao().insert(ActivityLog(timestamp = System.currentTimeMillis(), source = source, message = msg, status = status))

    fun refreshApps() = viewModelScope.launch(Dispatchers.IO) {
        apps.value = integrations.scan()
    }

    fun setEmergencyStop(on: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        prefs.emergencyStop = on
        val verified = Prefs(getApplication<Application>()).emergencyStop // re-read to verify
        stopped.value = verified
        log("Security", if (verified) "Emergency stop engaged" else "Agent resumed",
            if (verified == on) "OK" else "FAILED")
    }

    fun setAccent(argb: Int) { prefs.accent = argb; accent.value = prefs.accent }

    fun setConnected(entry: AppEntry, on: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        if (stopped.value) { log("Apps", "Blocked: emergency stop is on", "BLOCKED"); return@launch }
        if (on && !entry.installed) { log("Apps", "${entry.spec.label} is not installed", "FAILED"); return@launch }
        val old = db.connectionDao().get(entry.spec.packageName)
        db.connectionDao().upsert(
            AppConnection(entry.spec.packageName, entry.spec.label, on,
                if (on) old?.monitoring ?: false else false, System.currentTimeMillis())
        )
        val saved = db.connectionDao().get(entry.spec.packageName)
        log("Apps", "${entry.spec.label} ${if (on) "connected" else "disconnected"}",
            if (saved?.connected == on) "OK" else "FAILED")
    }

    fun setMonitoring(entry: AppEntry, on: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        val c = db.connectionDao().get(entry.spec.packageName) ?: return@launch
        if (!c.connected) return@launch
        db.connectionDao().upsert(c.copy(monitoring = on, updatedAt = System.currentTimeMillis()))
        val saved = db.connectionDao().get(entry.spec.packageName)
        log("Apps", "Monitoring ${if (on) "on" else "off"} for ${entry.spec.label}",
            if (saved?.monitoring == on) "OK" else "FAILED")
    }

    fun openApp(entry: AppEntry) = viewModelScope.launch(Dispatchers.Main) {
        val ok = runCatching { integrations.open(entry.spec.packageName) }.getOrDefault(false)
        withLog("Apps", "Open ${entry.spec.label}", ok)
    }

    private fun withLog(src: String, msg: String, ok: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        log(src, msg, if (ok) "OK" else "FAILED")
    }

    fun addMemory(text: String) = viewModelScope.launch(Dispatchers.IO) {
        if (text.isBlank()) return@launch
        db.memoryDao().insert(MemoryItem(encryptedText = KeystoreVault.encrypt(text.trim()), createdAt = System.currentTimeMillis()))
        log("Memory", "Saved a memory")
    }

    fun deleteMemory(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        db.memoryDao().delete(id)
        log("Memory", "Deleted a memory", if (db.memoryDao().exists(id) == 0) "OK" else "FAILED")
    }

    fun saveApiKey(key: String) = viewModelScope.launch(Dispatchers.IO) {
        if (key.isBlank()) return@launch
        prefs.saveApiKey(key.trim())
        val ok = prefs.apiKey() == key.trim()
        hasApiKey.value = prefs.hasApiKey()
        log("Security", "API key stored encrypted", if (ok) "OK" else "FAILED")
    }

    fun clearApiKey() = viewModelScope.launch(Dispatchers.IO) {
        prefs.clearApiKey(); hasApiKey.value = prefs.hasApiKey()
        log("Security", "API key removed")
    }

    fun deleteAllData() = viewModelScope.launch(Dispatchers.IO) {
        db.memoryDao().clear(); db.connectionDao().clear(); db.logDao().clear()
        prefs.clearApiKey(); hasApiKey.value = false
        message.value = "All stored data deleted"
    }

    fun clearMessage() { message.value = null }
}
