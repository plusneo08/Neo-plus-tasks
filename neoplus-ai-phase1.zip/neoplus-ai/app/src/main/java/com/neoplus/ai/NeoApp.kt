package com.neoplus.ai

import android.app.Application

class NeoApp : Application()
