package com.neoplus.ai.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity_log")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val source: String,
    val message: String,
    val status: String // OK, FAILED, BLOCKED
)

/** Text is stored encrypted with the Android Keystore key. */
@Entity(tableName = "memory_item")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val encryptedText: String,
    val createdAt: Long
)

@Entity(tableName = "app_connection")
data class AppConnection(
    @PrimaryKey val packageName: String,
    val label: String,
    val connected: Boolean,
    val monitoring: Boolean,
    val updatedAt: Long
)

@Entity(tableName = "callback")
data class Callback(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val triggerAt: Long,
    val repeatDaily: Boolean,
    val status: String, // PENDING, RINGING, ANSWERED, DECLINED, MISSED, CANCELLED, BLOCKED, FAILED
    val attempts: Int,
    val maxAttempts: Int,
    val retryMinutes: Int,
    val reason: String,
    val updatedAt: Long
)

@Dao
interface CallbackDao {
    @Insert suspend fun insert(c: Callback): Long
    @Update suspend fun update(c: Callback)
    @Query("SELECT * FROM callback WHERE id = :id") suspend fun get(id: Long): Callback?
    @Query("SELECT * FROM callback ORDER BY triggerAt DESC LIMIT 100") fun all(): Flow<List<Callback>>
    @Query("SELECT * FROM callback WHERE status IN ('PENDING','RINGING')") suspend fun open(): List<Callback>
    @Query("DELETE FROM callback") suspend fun clear()
}

@Dao
interface LogDao {
    @Insert suspend fun insert(log: ActivityLog)
    @Query("SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT 200")
    fun recent(): Flow<List<ActivityLog>>
    @Query("DELETE FROM activity_log") suspend fun clear()
}

@Dao
interface MemoryDao {
    @Insert suspend fun insert(item: MemoryItem)
    @Query("SELECT * FROM memory_item ORDER BY createdAt DESC")
    fun all(): Flow<List<MemoryItem>>
    @Query("SELECT COUNT(*) FROM memory_item WHERE id = :id") suspend fun exists(id: Long): Int
    @Query("DELETE FROM memory_item WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memory_item") suspend fun clear()
}

@Dao
interface ConnectionDao {
    @Upsert suspend fun upsert(c: AppConnection)
    @Query("SELECT * FROM app_connection WHERE packageName = :pkg")
    suspend fun get(pkg: String): AppConnection?
    @Query("SELECT * FROM app_connection")
    fun all(): Flow<List<AppConnection>>
    @Query("DELETE FROM app_connection") suspend fun clear()
}

@Database(
    entities = [ActivityLog::class, MemoryItem::class, AppConnection::class, Callback::class],
    version = 2,
    exportSchema = false
)
abstract class NeoDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao
    abstract fun memoryDao(): MemoryDao
    abstract fun connectionDao(): ConnectionDao
    abstract fun callbackDao(): CallbackDao

    companion object {
        @Volatile private var inst: NeoDatabase? = null
        fun get(ctx: Context): NeoDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, NeoDatabase::class.java, "neoplus.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}

/** Keeps memories and logs intact when the callback table is added. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `callback` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`triggerAt` INTEGER NOT NULL, `repeatDaily` INTEGER NOT NULL, `status` TEXT NOT NULL, " +
                "`attempts` INTEGER NOT NULL, `maxAttempts` INTEGER NOT NULL, `retryMinutes` INTEGER NOT NULL, " +
                "`reason` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL)"
        )
    }
}
